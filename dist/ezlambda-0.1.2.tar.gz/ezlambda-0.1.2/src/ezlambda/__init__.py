from .variable import Variable, VariableOperationMarker

__version__ = "0.1.2"

Var = Variable
VarMarker = VariableOperationMarker

_ = Var("_")
a = Var("a")
b = Var("b")
c = Var("c")
d = Var("d")
e = Var("e")
f = Var("f")
g = Var("g")
h = Var("h")
i = Var("i")
j = Var("j")
k = Var("k")
l = Var("l")
m = Var("m")
n = Var("n")
o = Var("o")
p = Var("p")
q = Var("q")
r = Var("r")
s = Var("s")
t = Var("t")
u = Var("u")
v = Var("v")
w = Var("w")
x = Var("x")
y = Var("y")
z = Var("z")

_m = VarMarker()
