from .variable import Variable, VariableOperationMarker

__version__ = "0.1.1"

Var = Variable
VarMarker = VariableOperationMarker

_ = Var()
x = Var()
y = Var()
z = Var()
w = Var()
t = Var()
a = Var()
b = Var()
c = Var()

_m = VarMarker()
